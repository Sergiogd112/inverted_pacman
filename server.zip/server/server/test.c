//
// Created by antonia on 6/05/23.
//
#include <stdio.h>
#include <unistd.h>
#include "main.h"
#include <ncurses.h>

int main() {

}
