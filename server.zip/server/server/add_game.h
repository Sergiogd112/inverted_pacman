#ifndef SERVER_PETICIONES_H
#define SERVER_PETICIONES_H
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include "logger.h"
#include "partida.h"

#endif // SERVER_PETICIONES_H