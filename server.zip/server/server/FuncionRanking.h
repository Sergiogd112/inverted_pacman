//
// Created by sergio on 22/03/23.
//

#ifndef SERVER_RANKING_H
#define SERVER_RANKING_H
// server.h : Include file for standard system include files,
// or project specific include files.

// #pragma once
#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include "config.h"

int Get_Ranking(MYSQL *conn, char res[1000]);

#endif // SERVER_RANKING_H
